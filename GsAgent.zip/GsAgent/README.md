# 🧠 Goal-Seeking Grid Agent

A simple AI agent that learns how to reach a goal on a 2D grid while avoiding obstacles.

## 🔍 How It Works
- The grid is represented as a 2D space.
- The agent can move one step at a time (up/down/left/right).
- It perceives the goal direction and chooses a movement.
- It avoids obstacles and invalid grid positions.

## ▶️ Run It

```bash
python main.py
